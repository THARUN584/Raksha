package com.example.rakshaapp1;

import android.Manifest;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private LocationManager locationManager;
    private TextView textView;
    private Button yesButton;
    private Button noButton;
    private static final String PRESCRIBED_NUMBER = "9380156401"; //
    private static final String PRESCRIBED_NUMBER1 = "7483908530";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private static final float SHAKE_THRESHOLD = 5f;
    private long lastShakeTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        yesButton = findViewById(R.id.yesButton);
        noButton = findViewById(R.id.noButton);

        setupLocationManager();
        yesButton.setVisibility(View.GONE);
        noButton.setVisibility(View.GONE);

        // Initialize the sensor manager and accelerometer sensor
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }

        yesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendLocationToPrescribedNumber();
            }
        });

        noButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle "No" button click if needed

                goBackToMain();

            }
        });
    }

    private void setupLocationManager() {
        // Initialize LocationManager
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // Request location updates
        if (locationManager != null) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission not granted, request it
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST_CODE);
            } else {
                // Permission granted, start listening for location updates
                startListeningForLocationUpdates();
            }
        }
    }

    private void startListeningForLocationUpdates() {
        // Request location updates
        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions

                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                    //  Toast.makeText(MainActivity.this, "New Location: " +
                    //  location.getLatitude() + ", " + location.getLongitude(), Toast.LENGTH_SHORT).show();
                }

                // Other LocationListener methods

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                }

                @Override
                public void onProviderEnabled(String provider) {
                }

                @Override
                public void onProviderDisabled(String provider) {
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, start listening for location updates
                startListeningForLocationUpdates();
            } else {
                // Permission denied, handle accordingly
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void goBackToMain() {
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
    @Override
    protected void onResume() {
        super.onResume();
        // Register the accelerometer sensor listener
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the accelerometer sensor listener
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Shake detection
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        float acceleration = (float) Math.sqrt(x * x + y * y + z * z);

        if (acceleration > 15) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastShakeTime >= SHAKE_THRESHOLD) {
                lastShakeTime = currentTime;
                yesButton.setVisibility(View.VISIBLE);
                noButton.setVisibility(View.VISIBLE);
                textView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle accuracy changes if needed
    }
    private void sendLocationToPrescribedNumber() {
        if (locationManager != null) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission not granted, check if permission can be requested
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                    // Explain to the user why the permission is needed (optional)
                    Toast.makeText(this, "SMS permission is required to send the location", Toast.LENGTH_SHORT).show();
                }
                // Request the permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        2);
            } else {
                // Permission already granted, send the location via SMS
                try {
                    Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                    if (lastKnownLocation != null) {
                        double latitude = lastKnownLocation.getLatitude();
                        double longitude = lastKnownLocation.getLongitude();
                        String message = "ALERT Help : http://maps.google.com/?q=" + latitude + "," + longitude;
                        SmsManager smsManager = SmsManager.getDefault();
                        SmsManager smsManager1 = SmsManager.getDefault();
                        smsManager.sendTextMessage(PRESCRIBED_NUMBER, null, message, null, null);
                        smsManager1.sendTextMessage(PRESCRIBED_NUMBER, null, message, null, null);
                        Toast.makeText(this, "Location sent Successfully", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(this, "Unable to get the location", Toast.LENGTH_SHORT).show();
                    }
                } catch (SecurityException e) {
                    // Handle SecurityException
                    Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }

        }
    }

    private void handleSendLocationButtonClick() {
        sendLocationToPrescribedNumber();

    }

}